-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: defconshop
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.31-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `color` varchar(255) NOT NULL,
  `price_net` decimal(15,2) NOT NULL,
  `price_gross` decimal(15,2) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_product_color` (`color`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Xiaomi phone','red',537.00,649.77,'product1.png'),(2,'Acer cheap','blue',799.00,966.79,'product2.png'),(3,'Toshiba pad','yellow',521.00,630.41,'product3.png'),(4,'Asus something','yellow',254.00,307.34,'product4.png'),(5,'Toshiba pad','green',737.00,891.77,'product5.png'),(6,'Apple Xpad','blue',415.00,502.15,'product6.png'),(7,'Toshiba pad','yellow',606.00,733.26,'product7.png'),(8,'Apple Imac','green',451.00,545.71,'product8.png'),(9,'Acer cheap','yellow',385.00,465.85,'product9.png'),(10,'Hp touch','green',374.00,452.54,'product10.png'),(11,'ZenPad','blue',638.00,771.98,'product11.png'),(12,'Hp touch','blue',723.00,874.83,'product12.png'),(13,'Toshiba pad','red',436.00,527.56,'product13.png'),(14,'ZenPad','yellow',738.00,892.98,'product14.png'),(15,'Xiaomi phone','yellow',880.00,1064.80,'product15.png'),(16,'Huawei phone','blue',548.00,663.08,'product16.png'),(17,'Toshiba pad','yellow',469.00,567.49,'product17.png'),(18,'Asus something','yellow',501.00,606.21,'product18.png'),(19,'Asus something','yellow',360.00,435.60,'product19.png'),(20,'Honor phone','green',997.00,1206.37,'product20.png');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-09-27 12:09:41
